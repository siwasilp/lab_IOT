#ifndef ANTO_COMMON_H
#define ANTO_COMMON_H

#define ANTO_VER    "v0.5.2"

#endif /* ifndef ANTO_COMMON_H */
