## 0.5.2 (2016-06-16)
* Add new overload methods for AntoIO::pub() (Integer, String, Character and Floating point)
* Edit example BasicMQTT
## 0.5.0 (2016-06-16)
* Add WiFi Manager (Smart config)
* Add example read temperature and humidity from DHT11 and send to server
## 0.4.1 (2016-05-31)
* Change client ID in MQTT connection
* Reformat API
* Add quick start anto example
## 0.3.0 (2016-05-30)
* Add MQTT subscribe or HTTP request for data service
## 0.2.0 (2016-04-23)
* Add MQTT client
* Modify HTTP request method
## 0.1.1 (2016-01-09)
* Delete internal libraries
## 0.1.0 (2015-11-28)
* Add Get/Set data channel via HTTP
* First release
